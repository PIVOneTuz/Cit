import React from "react";

export default class Preloader extends React.Component {
  render() {
    return (
      <div id="preloader">
        <img src="classic1.gif" />
      </div>
    );
  }
}
