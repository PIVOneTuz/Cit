import React from "react";

export default class MainPage extends React.Component {
  render() {
    return (
      <div id="main">
        <h3>Register to avoid leaking interesting information!</h3>
      </div>
    );
  }
}
